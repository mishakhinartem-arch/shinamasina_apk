// Автотесты ключевой логики демо-кассы. Запуск: node --test tests/
const test = require("node:test");
const assert = require("node:assert/strict");
const SM = require("./load.js");
const H = 36e5;
const T0 = new Date(2026, 10, 18, 9, 0).getTime(); // 18.11.2026 09:00
function fresh() { SM.clock.fixed = T0; const S = SM.emptyState(); S.employees = [{ id: "a", name: "А", percent: 40, active: true }, { id: "b", name: "Б", percent: 40, active: true }]; return S; }
const emps = [{ id: "a", name: "А", percent: 40 }, { id: "b", name: "Б", percent: 40 }];

test("ЗП: пример из рабочей кассы (Александр один до 13:00, потом вдвоём) + округление до 50 ₽", () => {
  const sh = { startedAt: T0, endedAt: T0 + 12 * H, att: [{ empId: "a", in: T0, out: null }, { empId: "b", in: T0 + 4 * H, out: null }] };
  const ledger = [{ ts: T0 + 2 * H, delta: 20000 }, { ts: T0 + 6 * H, delta: 80000 }];
  const r = SM.payroll.calcShift(sh, ledger, emps, SM.DEFAULT_SETTINGS, T0 + 12 * H);
  assert.equal(r[0].raw, 24000); assert.equal(r[0].pay, 24000);
  assert.equal(r[1].raw, 16000); assert.equal(r[1].pay, 16000);
  const r2 = SM.payroll.calcShift(sh, [{ ts: T0 + 6 * H, delta: 10130 }], emps, SM.DEFAULT_SETTINGS, T0 + 12 * H);
  assert.equal(r2[0].raw, 2026); // 10130 × 40% / 2
  assert.equal(r2[0].rounded, 2050); // ближайшие 50 ₽
  assert.equal(SM.round50(2024), 2000); assert.equal(SM.round50(2025), 2050);
});
test("ЗП: минимум 4 000 ₽ только при ≥ 8 ч, при любом числе мастеров", () => {
  const ledger = [{ ts: T0 + 1 * H, delta: 5000 }];
  // 8 ч ровно — минимум положен
  let sh = { startedAt: T0, endedAt: T0 + 8 * H, att: [{ empId: "a", in: T0, out: T0 + 8 * H }, { empId: "b", in: T0, out: T0 + 8 * H }] };
  let r = SM.payroll.calcShift(sh, ledger, emps, SM.DEFAULT_SETTINGS);
  assert.equal(r[0].pay, 4000); assert.equal(r[0].minApplied, true); assert.equal(r[0].rounded, 1000);
  // 7 ч 59 мин — только процент
  sh = { startedAt: T0, endedAt: T0 + 8 * H, att: [{ empId: "a", in: T0, out: T0 + 8 * H - 60e3 }] };
  r = SM.payroll.calcShift(sh, ledger, emps, SM.DEFAULT_SETTINGS);
  assert.equal(r[0].pay, 2000); assert.equal(r[0].minApplied, false); assert.equal(r[0].minEligible, false);
  assert.ok(r[0].hoursTo8 > 0 && r[0].hoursTo8 < 0.02);
  // один мастер, 10 ч, процент выше минимума — минимум не нужен
  sh = { startedAt: T0, endedAt: T0 + 10 * H, att: [{ empId: "a", in: T0, out: null }] };
  r = SM.payroll.calcShift(sh, [{ ts: T0 + H, delta: 30000 }], emps, SM.DEFAULT_SETTINGS);
  assert.equal(r[0].pay, 12000); assert.equal(r[0].minApplied, false);
});
test("ЗП: пришёл днём — считается с момента прихода, выручка до прихода не делится на него", () => {
  const S = fresh(); SM.shift.open(S, ["a"], 0);
  const sh = SM.shift.current(S);
  S.receipts.push({ ts: T0 + H, shiftId: sh.id, kind: "service", total: 10000, payment: "card" });
  SM.clock.fixed = T0 + 3 * H; SM.shift.clockIn(S, "b", 0);
  S.receipts.push({ ts: T0 + 4 * H, shiftId: sh.id, kind: "service", total: 10000, payment: "card" });
  const rows = SM.payroll.forShift(S, sh, T0 + 5 * H);
  assert.equal(rows.find((r) => r.empId === "a").raw, 6000); // 4000 + 2000
  assert.equal(rows.find((r) => r.empId === "b").raw, 2000);
});
test("Закрытие смены: ЗП из налички ящика, не хватает — выдаём сколько есть, остальное долг; день дважды не оплатить", () => {
  const S = fresh(); S.drawer.balance = 1000; SM.shift.open(S, ["a"], 1000);
  const sh = SM.shift.current(S);
  S.receipts.push({ ts: T0 + H, shiftId: sh.id, kind: "service", total: 2000, payment: "cash" }); SM.shift.drawerMove(S, 2000, "sale");
  SM.clock.fixed = T0 + 9 * H;
  const r = SM.shift.close(S);
  assert.equal(r.rows[0].pay, 4000); assert.equal(r.rows[0].paid, 3000); assert.equal(r.rows[0].debt, 1000);
  assert.equal(S.drawer.balance, 0);
  assert.equal(SM.payroll.payDay(S, { empId: "a", day: SM.dayKey(T0), amount: 100 }).ok, false);
  // вторая смена в тот же день — сумма уходит в долг
  S.drawer.balance = 50000; SM.clock.fixed = T0 + 10 * H; SM.shift.open(S, ["a"], 50000); SM.clock.fixed = T0 + 11 * H;
  const r2 = SM.shift.close(S);
  assert.equal(r2.rows[0].paid, 0); assert.ok(r2.summary.notes[0].indexOf("уже оплачен") > 0);
});
test("Надбавка +20% — на Монтаж/Демонтаж/Переобувку 4/Итого за 1 колесо целиком, не на балансировку", () => {
  const S = fresh(); const ctx = { radius: "R16", typeKey: "passenger" };
  const o = { items: [], runflat: true, history: [] };
  ["r:Переобувка 4 колеса", "r:Балансировка", "r:Монтаж", "f:Ремонт жгутом"].forEach((k) => SM.orders.addItem(S, o, SM.prices.find(S.prices, k, "passenger", "R16"), 1, ctx, "т"));
  const t = SM.cart.totals(o, S.settings);
  assert.equal(t.base, 3700 + 330 + 205 + 500);
  assert.equal(t.surchargeBase, 3700 + 205);
  assert.equal(t.surcharge, 781);
  assert.equal(t.total, 3700 + 330 + 205 + 500 + 781);
  o.loyalty = true; // 10% от суммы с надбавкой, как сейчас
  assert.equal(SM.cart.totals(o, S.settings).discount, Math.round((4735 + 781) * 0.1));
});
test("Лимит скидки: % и ₽ (₽ → % от заказа), 0 = без ограничений", () => {
  const st = Object.assign({}, SM.DEFAULT_SETTINGS, { discountMaxPct: 15, discountMaxRub: 1000 });
  const o = { items: [{ price: 4000, qty: 1 }], discount: { type: "rub", value: 600 } };
  assert.equal(SM.cart.checkDiscount(o, st).ok, true); // 600 ≤ 15% (600)
  o.discount = { type: "rub", value: 601 }; assert.equal(SM.cart.checkDiscount(o, st).ok, false);
  o.items = [{ price: 10000, qty: 1 }]; o.discount = { type: "pct", value: 12 }; // 1200 > 1000 ₽ (=10%)
  const c = SM.cart.checkDiscount(o, st); assert.equal(c.ok, false); assert.match(c.msg, /лимит/); assert.equal(c.limit.rub, 1000);
  assert.equal(SM.cart.checkDiscount(o, Object.assign({}, st, { discountMaxPct: 0, discountMaxRub: 0 })).ok, true);
  // скидка постоянному 10% в лимит не входит
  assert.equal(SM.cart.checkDiscount({ items: [{ price: 20000, qty: 1 }], loyalty: true, discount: { type: "rub", value: 1000 } }, st).ok, true);
  // через заказ: сверх лимита не сохраняется
  const S = fresh(); const ord = SM.orders.create(S, { plate: "А123ВС50" }, "т").order; ord.items.push({ price: 2000, qty: 1 });
  assert.equal(SM.orders.setDiscount(S, ord, { type: "pct", value: 50 }, "т").ok, false); assert.equal(ord.discount, null);
  assert.equal(SM.orders.setDiscount(S, ord, { type: "pct", value: 10 }, "т").ok, true);
  assert.ok(ord.history.some((h) => /Скидка/.test(h.text)));
});
test("Заказ только по госномеру/очереди, клиент подтягивается, статусы и оплата, автосписание склада с учётом кол-ва", () => {
  const S = fresh(); SM.shift.open(S, ["a"], 0);
  SM.addClient(S, { name: "Тест", phone: "79000000099", plate: "А123ВС50", wheel_size: "R16" });
  assert.equal(SM.orders.create(S, {}, "т").ok, false);
  const o = SM.orders.create(S, { plate: "a123bc50" }, "т").order;
  assert.ok(o.clientId);
  S.warehouse.items = [{ id: "w1", name: "Грузики", unit: "г", cost: 1, min: 100, qty: 1000 }, { id: "w8", name: "Пакеты", unit: "шт", cost: 6, min: 10, qty: 50 }];
  SM.warehouse.setNorm(S, "r:Балансировка", "w1", 25); SM.warehouse.setNorm(S, "gift", "w8", 1);
  SM.orders.addItem(S, o, SM.prices.find(S.prices, "r:Балансировка", "passenger", "R16"), 4, { radius: "R16", typeKey: "passenger" }, "т");
  SM.orders.addItem(S, o, SM.prices.find(S.prices, "gift", "passenger", "R16"), 4, {}, "т");
  SM.orders.setStatus(S, o, "work", "т"); SM.orders.setStatus(S, o, "ready", "т");
  const r = SM.orders.pay(S, o, "cash", "т");
  assert.equal(r.ok, true); assert.equal(o.status, "done"); assert.equal(r.receipt.total, 1320);
  assert.equal(SM.warehouse.item(S, "w1").qty, 900); assert.equal(SM.warehouse.item(S, "w8").qty, 46);
  assert.equal(r.writeoff.cost, 100 + 24);
  assert.equal(S.drawer.balance, 1320);
  const q = SM.queueAdd(S); assert.equal(SM.orders.create(S, { queueNo: q.no }, "т").ok, true);
});
test("Склад: приход по средней цене, ручное списание, инвентаризация, «заканчивается»", () => {
  const S = fresh(); S.warehouse.items = [{ id: "w", name: "Вентиль", unit: "шт", cost: 10, min: 20, qty: 10 }];
  assert.equal(SM.warehouse.low(S).length, 1);
  SM.warehouse.receive(S, { supplier: "X", lines: [{ itemId: "w", qty: 10, price: 20 }] });
  assert.equal(SM.warehouse.item(S, "w").qty, 20); assert.equal(SM.warehouse.item(S, "w").cost, 15);
  assert.equal(SM.warehouse.low(S).length, 0);
  assert.equal(SM.warehouse.writeOff(S, "w", 2, "Брак").ok, true);
  const d = SM.warehouse.inventory(S, { w: 15 }, true); assert.equal(d[0].diff, -3); assert.equal(SM.warehouse.item(S, "w").qty, 15);
  assert.equal(SM.warehouse.costInRange(S, 0, T0 + H), (2 + 3) * 15);
});
test("Постоянные расходы: не задним числом (число прошло → со следующего месяца), с выбором «с этого месяца»", () => {
  const S = fresh(); // сегодня 18-е
  const a = SM.expenses.addRecurring(S, { name: "Аренда", amount: 60000, day: 5 }).rec;
  assert.equal(a.startMonth, "2026-12");
  const b = SM.expenses.addRecurring(S, { name: "Свет", amount: 7000, day: 20 }).rec;
  assert.equal(b.startMonth, "2026-11");
  const c = SM.expenses.addRecurring(S, { name: "Интернет", amount: 1500, day: 10 }, true).rec;
  assert.equal(c.startMonth, "2026-11");
  const nov = SM.expenses.inRange(S, ...SM.monthRange("2026-11")); assert.deepEqual(nov.map((e) => e.amount).sort(), [1500, 7000]);
  const dec = SM.expenses.inRange(S, ...SM.monthRange("2026-12")); assert.equal(dec.reduce((s, e) => s + e.amount, 0), 68500);
});
test("Чистая прибыль = выручка − ЗП (смены + премии − штрафы) − расходы − себестоимость расходников", () => {
  const S = fresh(); SM.shift.open(S, ["a"], 0);
  S.warehouse.items = [{ id: "w1", name: "Грузики", unit: "г", cost: 2, min: 0, qty: 1000 }]; SM.warehouse.setNorm(S, "r:Балансировка", "w1", 25);
  const o = SM.orders.create(S, { plate: "В777ВВ77" }, "т").order;
  SM.orders.addItem(S, o, SM.prices.find(S.prices, "r:Переобувка 4 колеса", "passenger", "R16"), 1, { radius: "R16", typeKey: "passenger" }, "т");
  SM.orders.addItem(S, o, SM.prices.find(S.prices, "r:Балансировка", "passenger", "R16"), 4, { radius: "R16", typeKey: "passenger" }, "т");
  SM.orders.pay(S, o, "card", "т"); // 3700 + 1320 = 5020, расходники 100 г × 2 = 200
  const st = SM.storage.create(S, { plate: "В777ВВ77", phone: "79000000098", qty: 4, size: "205/55 R16", place: "А-1", months: 6, payNow: "cash" }); // тариф R16: 3500
  assert.equal(st.ok, true);
  SM.clock.fixed = T0 + 9 * H; SM.shift.close(S); // ЗП: 5020×40% = 2008 → 2000, 9 ч → минимум 4000
  SM.payroll.addAdjustment(S, { empId: "a", type: "bonus", amount: 1000 }); SM.payroll.addAdjustment(S, { empId: "a", type: "fine", amount: 300 }); SM.payroll.addAdjustment(S, { empId: "a", type: "advance", amount: 2000 });
  SM.expenses.addOneoff(S, { name: "Ветошь", amount: 500, ts: T0 + 2 * H });
  const r = SM.reports.month(S, "2026-11");
  assert.equal(st.rec.price, 3500);
  assert.equal(r.revenue, 8520); assert.equal(r.storage, 3500); assert.equal(r.checks, 1); assert.equal(r.avgCheck, 5020);
  assert.equal(r.payroll, 4000 + 1000 - 300); assert.equal(r.expenses, 500); assert.equal(r.material, 200);
  assert.equal(r.profit, 8520 - 4700 - 500 - 200);
  const slip = SM.payroll.payslip(S, "a", ...SM.monthRange("2026-11"));
  assert.equal(slip.accrued, 4700); assert.equal(slip.advance, 2000); assert.equal(slip.paid, slip.paidShift + 2000);
});
test("Хранение: статусы «истекает (14 дн.)» и «просрочено»; запись: слоты, согласие, пометка «привезти со склада»", () => {
  const S = fresh(); const today = SM.dayStart(T0);
  const mk = (d) => SM.storage.create(S, { plate: "Е" + (100 + d + 50) + "КХ77", phone: "7900000" + String(1000 + d + 50).slice(-4), qty: 4, size: "R16", place: "A", until: today + d * 864e5, price: 0 }).rec;
  assert.equal(SM.storage.status(S, mk(-1)), "overdue"); assert.equal(SM.storage.status(S, mk(14)), "soon"); assert.equal(SM.storage.status(S, mk(15)), "ok");
  const day = SM.dayKey(T0 + 864e5);
  assert.equal(SM.booking.create(S, { name: "И", phone: "79000000011", direction: "tire", date: day, time: "10:00" }).ok, false); // без согласия
  const b = SM.booking.create(S, { name: "И", phone: "79000000011", direction: "tire", date: day, time: "10:00", consent: true, plate: "Е149КХ77" });
  assert.equal(b.ok, true); assert.equal(SM.booking.needsStorage(S, b.booking), true);
  SM.booking.create(S, { name: "П", phone: "79000000012", direction: "tire", date: day, time: "10:00", consent: true });
  assert.equal(SM.booking.create(S, { name: "Р", phone: "79000000013", direction: "tire", date: day, time: "10:00", consent: true }).ok, false); // слот на 2 машины занят
  const acc = SM.booking.accept(S, b.booking, "т"); assert.equal(acc.ok, true); assert.equal(acc.order.plate, "Е149КХ77");
});
test("Прайс Excel: выгрузка → правка → сравнение было/стало → применение; клавиатура номера", () => {
  const P = JSON.parse(JSON.stringify(globalThis.PRICES));
  const rows = SM.excel.priceRows(P);
  const row = rows.find((r) => r["Раздел"] === "Легковые" && r["Услуга"] === "Балансировка" && r["Радиус"] === "R16");
  assert.equal(row["Цена, ₽"], 330); row["Цена, ₽"] = 350;
  rows.find((r) => r["Услуга"] === "Подкачка")["Цена, ₽"] = "0";
  const d = SM.excel.diff(P, rows); assert.equal(d.changes.length, 1); assert.equal(d.changes[0].was, 330); assert.equal(d.errors.length, 1);
  SM.excel.apply(P, d.changes); assert.equal(SM.prices.radiusPrice(P, "passenger", "Балансировка", "R16"), 350);
  assert.equal(SM.plateValid("А123ВС50"), true); assert.equal(SM.plateValid("А123ВС750"), true); assert.equal(SM.plateValid("Б123ВС50"), false); assert.equal(SM.plateMiddle("В770СУ797"), "770");
});
test("Демо-данные: ~2 месяца чеков, хранение просрочено/истекает, склад ниже минимума, открытая смена", () => {
  SM.clock.fixed = null; const S = SM.seed();
  assert.ok(S.receipts.length > 300); assert.ok(S.shifts.filter((s) => s.endedAt).length > 40);
  assert.ok(S.storage.some((r) => SM.storage.status(S, r) === "overdue")); assert.ok(S.storage.some((r) => SM.storage.status(S, r) === "soon"));
  assert.equal(SM.warehouse.low(S).length, 2); assert.ok(SM.shift.current(S));
  assert.ok(S.clients.every((c) => c.phone.startsWith("790000000")));
});

// ---------- п.2 (решение Артёма): хранение — фиксированный тариф, скидки на хранение не действуют ----------
test("Хранение: цена по тарифу владельца (радиус, срок, диски, кол-во), подставляется сама; изменение тарифа в админке", () => {
  const S = fresh();
  const c = (d) => SM.storage.calcPrice(S, d);
  assert.equal(c({ radius: "R16", months: 6, qty: 4 }).price, 3500);
  assert.equal(c({ size: "225/45 R17", months: 6, qty: 4 }).price, 3800); // радиус из размера
  assert.equal(c({ radius: "R16", months: 6, qty: 4, rims: true }).price, 4000); // + диски 500
  assert.equal(c({ radius: "R16", months: 3, qty: 4 }).price, 1750); // пропорционально сроку
  assert.equal(c({ radius: "R16", months: 6, qty: 2 }).price, 1750); // пропорционально числу шин
  assert.equal(c({ radius: "R15", months: 7, qty: 4 }).price, 3750); // 3200×7/6 = 3733 → 3750 (до 50 ₽)
  assert.equal(c({ radius: "R99", months: 6 }).ok, false);
  // приём: цена подставляется по тарифу, ручная цена без priceOverride игнорируется
  let r = SM.storage.create(S, { plate: "А111АА77", phone: "79000000001", qty: 4, size: "205/55 R16", place: "А-1", months: 6, price: 100 });
  assert.equal(r.ok, true); assert.equal(r.rec.price, 3500); assert.equal(r.rec.priceManual, false); assert.equal(r.rec.months, 6);
  assert.equal(SM.dayKey(r.rec.until), "2027-05-18");
  // владелец поменял тариф → следующий приём по новой цене, старый комплект не меняется
  S.settings.storageTariff.R16 = 4000;
  const r2 = SM.storage.create(S, { plate: "А222АА77", phone: "79000000002", qty: 4, size: "205/55 R16", place: "А-2", months: 6 });
  assert.equal(r2.rec.price, 4000); assert.equal(r.rec.price, 3500);
  // ручная цена — только с priceOverride (в интерфейсе — после PIN владельца)
  const r3 = SM.storage.create(S, { plate: "А333АА77", phone: "79000000003", qty: 4, size: "205/55 R16", place: "А-3", months: 6, price: 3000, priceOverride: true });
  assert.equal(r3.rec.price, 3000); assert.equal(r3.rec.priceManual, true);
  assert.equal(SM.storage.create(S, { plate: "А444АА77", phone: "79000000004", qty: 4, size: "205/55 R99", place: "А-4", months: 6 }).ok, false);
});
test("Чек со скидкой: скидка постоянному и ручная — только на услуги, хранение по полной цене и не в базе ЗП мастеров", () => {
  const S = fresh(); SM.shift.open(S, ["a"], 0);
  SM.addClient(S, { name: "Пост", phone: "79000000077", plate: "К777КК77", wheel_size: "R16" });
  const st = SM.storage.create(S, { plate: "К777КК77", qty: 4, size: "205/55 R16", place: "Б-1", months: 6 }).rec; // 3500
  const o = SM.orders.create(S, { plate: "К777КК77" }, "т").order;
  o.loyalty = true;
  SM.orders.addItem(S, o, SM.prices.find(S.prices, "r:Переобувка 4 колеса", "passenger", "R16"), 1, { radius: "R16", typeKey: "passenger" }, "т"); // 3700
  assert.equal(SM.orders.addStorage(S, o, st, "т").ok, true);
  assert.equal(SM.orders.addStorage(S, o, st, "т").ok, false); // второй раз нельзя
  assert.equal(SM.storage.pay(S, st, "cash").ok, false); // отдельно не оплатить, пока в чеке заказа
  const si = o.items.find((i) => i.storageId);
  assert.equal(SM.orders.setPrice(S, o, si.id, 100, "т").ok, false); // цена хранения фиксированная
  SM.orders.setQty(S, o, si.id, 2, "т"); assert.equal(si.qty, 1);
  let t = SM.cart.totals(o, S.settings);
  assert.equal(t.discountBase, 3700); assert.equal(t.storage, 3500); assert.equal(t.loyalty, 370); assert.equal(t.total, 3700 - 370 + 3500);
  // ручная 10% — тоже только от услуг; лимит считается от услуг
  assert.equal(SM.orders.setDiscount(S, o, { type: "pct", value: 10 }, "т").ok, true);
  t = SM.cart.totals(o, S.settings); assert.equal(t.manual, 370); assert.equal(t.discount, 740); assert.equal(t.total, 3700 - 740 + 3500);
  // ₽-скидка больше услуг не «съедает» хранение
  S.settings.discountMaxPct = 0; S.settings.discountMaxRub = 0;
  assert.equal(SM.orders.setDiscount(S, o, { type: "rub", value: 99999 }, "т").ok, true);
  t = SM.cart.totals(o, S.settings); assert.equal(t.discount, 3700); assert.equal(t.total, 3500);
  SM.orders.setDiscount(S, o, { type: "pct", value: 10 }, "т");
  // лимит 15% / 1000 ₽ — от суммы услуг 3700 (не от 7200 с хранением): 1000 ₽ = 27% → строже 15% = 555 ₽
  S.settings.discountMaxPct = 15; S.settings.discountMaxRub = 1000;
  assert.equal(SM.cart.discountLimit(S.settings, t.discountBase).rub, 555);
  assert.equal(SM.cart.checkDiscount(Object.assign({}, o, { discount: { type: "rub", value: 600 } }), S.settings).ok, false);
  SM.clock.fixed = T0 + H;
  const r = SM.orders.pay(S, o, "card", "т");
  assert.equal(r.ok, true); assert.equal(r.receipt.total, 2960 + 3500);
  assert.equal(st.paid, true); assert.equal(st.receiptId, r.receipt.id);
  // ЗП мастера: 40% только от услуг (2960), хранение не входит
  const sh = SM.shift.current(S);
  const ledger = SM.payroll.ledgerFor(S, sh.id); assert.equal(ledger[0].delta, 2960);
  assert.equal(SM.payroll.forShift(S, sh, T0 + 2 * H)[0].raw, 1184);
  // отчёт: услуги и хранение раздельно, хранение не в «топе услуг»
  const rep = SM.reports.range(S, T0 - H, T0 + 3 * H);
  assert.equal(rep.services, 2960); assert.equal(rep.storage, 3500); assert.equal(rep.revenue, 6460);
  assert.ok(!rep.topServices.some((x) => /Хранение/.test(x.name)));
  assert.equal(SM.shift.revenue(S, sh.id).storage, 3500);
  // «Как в прошлый раз» не повторяет хранение
  const o2 = SM.orders.create(S, { plate: "К777КК77" }, "т").order; SM.orders.repeatLast(S, o2, "т");
  assert.ok(o2.items.length === 1 && !o2.items.some((i) => i.storageId));
});
// ---------- п.4 (решение Артёма): грузики — только коробками, без норм на машину ----------
test("Склад: грузики только коробками — нет норм, нет автосписания, приход/выдача/инвентаризация целыми коробками", () => {
  const S0 = SM.seed();
  const box = S0.warehouse.items.filter((i) => SM.warehouse.isBox(i));
  assert.deepEqual(box.map((i) => i.id).sort(), ["w1", "w2"]);
  assert.ok(box.every((i) => i.unit === "кор" && Number.isInteger(i.qty)));
  assert.equal(S0.warehouse.norms.filter((n) => n.itemId === "w1" || n.itemId === "w2").length, 0);
  assert.ok(S0.warehouse.norms.some((n) => n.itemId === "w7")); // остальные нормы на месте (монтажная паста)
  assert.ok(S0.warehouse.moves.some((m) => m.type === "box")); // в истории есть выдачи коробок
  const S = fresh(); SM.shift.open(S, ["a"], 0);
  S.warehouse.items = [{ id: "w1", name: "Грузики набивные (коробка)", unit: "кор", cost: 2400, min: 2, qty: 3, box: true }, { id: "w7", name: "Паста", unit: "г", cost: 0.35, min: 0, qty: 1000 }];
  assert.equal(SM.warehouse.setNorm(S, "r:Балансировка", "w1", 25).ok, false);
  assert.equal(S.warehouse.norms.length, 0);
  S.warehouse.norms.push({ id: "old", key: "r:Балансировка", itemId: "w1", perUnit: 25 }); // старая норма из прежних данных — игнорируется
  SM.warehouse.setNorm(S, "r:Монтаж", "w7", 5);
  const o = SM.orders.create(S, { plate: "Р100РР77" }, "т").order;
  SM.orders.addItem(S, o, SM.prices.find(S.prices, "r:Балансировка", "passenger", "R16"), 4, { radius: "R16", typeKey: "passenger" }, "т");
  SM.orders.addItem(S, o, SM.prices.find(S.prices, "r:Монтаж", "passenger", "R16"), 4, { radius: "R16", typeKey: "passenger" }, "т");
  const p = SM.orders.pay(S, o, "cash", "т");
  assert.equal(SM.warehouse.item(S, "w1").qty, 3); // грузики не списались
  assert.equal(SM.warehouse.item(S, "w7").qty, 980); // паста списалась по норме
  assert.ok(!p.writeoff.lines.some((l) => l.itemId === "w1"));
  assert.equal(SM.warehouse.writeOff(S, "w1", 0.5, "Выдана в работу").ok, false);
  assert.equal(SM.warehouse.writeOff(S, "w1", 5, "Выдана в работу").ok, false); // больше, чем есть
  const w = SM.warehouse.writeOff(S, "w1", 1, "Выдана в работу");
  assert.equal(w.ok, true); assert.equal(w.move.type, "box"); assert.equal(SM.warehouse.item(S, "w1").qty, 2);
  assert.equal(SM.warehouse.receive(S, { lines: [{ itemId: "w1", qty: 1.5, price: 2400 }] }).ok, false);
  assert.equal(SM.warehouse.receive(S, { lines: [{ itemId: "w1", qty: 2, price: 2400 }] }).ok, true);
  assert.equal(SM.warehouse.item(S, "w1").qty, 4);
  assert.equal(SM.warehouse.inventory(S, { w1: 3.7 }, false).length, 0); // дробный факт не принимается
  assert.equal(SM.warehouse.inventory(S, { w1: 3 }, true)[0].diff, -1);
  assert.equal(SM.warehouse.costInRange(S, 0, T0 + 5 * H), SM.round2(20 * 0.35 + 2400 + 2400)); // паста + выданная коробка + недостача коробки
});
test("Документы: договор хранения и согласие на ПД — шаблоны с реквизитами ИП, поля клиента подставляются", () => {
  const D = SM.DOCS;
  for (const h of [D.contract, D.consent]) { assert.ok(/773580864120/.test(h) && /325774600692668/.test(h) && /Андреевка/.test(h) && /юристом не проверен/i.test(h)); }
  assert.ok(/Акт приёма/.test(D.contract) && /непреодолимой силы/.test(D.contract) && /ст\. 899/.test(D.contract));
  assert.ok(/Цели обработки/.test(D.consent) && /госномер|регистрационный номер/.test(D.consent) && /отозвать/.test(D.consent));
  const f = SM.docFill(D.contract, { "ФИО клиента": "Иван <демо>", "Номер договора": "Х-0001" });
  assert.ok(f.includes("Иван &lt;демо&gt;") && f.includes("Х-0001") && !/data-f=/.test(f));
});
